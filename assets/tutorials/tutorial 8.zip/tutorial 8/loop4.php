function bubble_sort($arr) {
    $n = count($arr);
    
    for ($i = 0; $i < $n; $i++) {
        for ($j = 0; $j < $n - $i - 1; $j++) {
            if ($arr[$j] > $arr[$j + 1]) {
                $temp = $arr[$j];
                $arr[$j] = $arr[$j + 1];
                $arr[$j + 1] = $temp;
            }
        }
    }
    
    return $arr;
}

$arr = [11, 22, 44, 19, 4, 5, 33, 16, 8, 55];
print_r(bubble_sort($arr));

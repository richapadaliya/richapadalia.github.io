for ($row = 0; $row < 8; $row++) {
    for ($col = 0; $col < 8; $col++) {
        if (($row + $col) % 2 == 0) {
            echo "&nbsp;&nbsp;";
        } else {
            echo "#&nbsp;&nbsp;";
        }
    }
    echo "<br>";
}

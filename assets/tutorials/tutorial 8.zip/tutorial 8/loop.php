
<?php

$first = 0;
$second = 1;
$counter = 0;

do {
    echo $first . " ";
    $third = $first + $second;
    $first = $second;
    $second = $third;
    $counter++;
} while ($counter < 10);


?>


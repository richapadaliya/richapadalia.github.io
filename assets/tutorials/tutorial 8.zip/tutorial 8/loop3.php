<?php
function isPrime($num) {
    if ($num < 2) {
        return false;
    }

    for ($i = 2; $i <= sqrt($num); $i++) {
        if ($num % $i == 0) {
            return false;
        }
    }

    return true;
}

echo "Enter the value of N: ";
$n = (int)fgets(STDIN);
$count = 0;
$num = 2;

echo "The first $n prime numbers are:\n";
while ($count < $n) {
    if (isPrime($num)) {
        echo "$num\n";
        $count++;
    }
    $num++;
}
?>
